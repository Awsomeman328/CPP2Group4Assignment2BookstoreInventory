/********************************************************************************
** Form generated from reading UI file 'hardwareinfo.ui'
**
** Created by: Qt User Interface Compiler version 6.4.3
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_HARDWAREINFO_H
#define UI_HARDWAREINFO_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QMainWindow>
#include <QtWidgets/QMenuBar>
#include <QtWidgets/QStatusBar>
#include <QtWidgets/QTableWidget>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_hardwareInfo
{
public:
    QWidget *centralwidget;
    QTableWidget *tableWidget;
    QMenuBar *menubar;
    QStatusBar *statusbar;

    void setupUi(QMainWindow *hardwareInfo)
    {
        if (hardwareInfo->objectName().isEmpty())
            hardwareInfo->setObjectName("hardwareInfo");
        hardwareInfo->resize(800, 600);
        centralwidget = new QWidget(hardwareInfo);
        centralwidget->setObjectName("centralwidget");
        tableWidget = new QTableWidget(centralwidget);
        if (tableWidget->columnCount() < 2)
            tableWidget->setColumnCount(2);
        if (tableWidget->rowCount() < 8)
            tableWidget->setRowCount(8);
        tableWidget->setObjectName("tableWidget");
        tableWidget->setGeometry(QRect(110, 30, 551, 391));
        tableWidget->setRowCount(8);
        tableWidget->setColumnCount(2);
        hardwareInfo->setCentralWidget(centralwidget);
        menubar = new QMenuBar(hardwareInfo);
        menubar->setObjectName("menubar");
        menubar->setGeometry(QRect(0, 0, 800, 22));
        hardwareInfo->setMenuBar(menubar);
        statusbar = new QStatusBar(hardwareInfo);
        statusbar->setObjectName("statusbar");
        hardwareInfo->setStatusBar(statusbar);

        retranslateUi(hardwareInfo);

        QMetaObject::connectSlotsByName(hardwareInfo);
    } // setupUi

    void retranslateUi(QMainWindow *hardwareInfo)
    {
        hardwareInfo->setWindowTitle(QCoreApplication::translate("hardwareInfo", "MainWindow", nullptr));
    } // retranslateUi

};

namespace Ui {
    class hardwareInfo: public Ui_hardwareInfo {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_HARDWAREINFO_H
