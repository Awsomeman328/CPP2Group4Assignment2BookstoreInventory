/********************************************************************************
** Form generated from reading UI file 'logindialog.ui'
**
** Created by: Qt User Interface Compiler version 6.4.3
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_LOGINDIALOG_H
#define UI_LOGINDIALOG_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QDialog>
#include <QtWidgets/QGroupBox>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QPushButton>

QT_BEGIN_NAMESPACE

class Ui_loginDialog
{
public:
    QGroupBox *groupBox;
    QLineEdit *username;
    QLineEdit *password;
    QPushButton *loginbutton;
    QPushButton *exitbutton;

    void setupUi(QDialog *loginDialog)
    {
        if (loginDialog->objectName().isEmpty())
            loginDialog->setObjectName("loginDialog");
        loginDialog->resize(400, 300);
        groupBox = new QGroupBox(loginDialog);
        groupBox->setObjectName("groupBox");
        groupBox->setGeometry(QRect(20, 20, 361, 261));
        username = new QLineEdit(groupBox);
        username->setObjectName("username");
        username->setGeometry(QRect(40, 90, 131, 31));
        password = new QLineEdit(groupBox);
        password->setObjectName("password");
        password->setGeometry(QRect(200, 90, 131, 31));
        loginbutton = new QPushButton(groupBox);
        loginbutton->setObjectName("loginbutton");
        loginbutton->setGeometry(QRect(60, 160, 93, 29));
        exitbutton = new QPushButton(groupBox);
        exitbutton->setObjectName("exitbutton");
        exitbutton->setGeometry(QRect(210, 160, 93, 29));

        retranslateUi(loginDialog);
        QObject::connect(exitbutton, &QPushButton::clicked, loginDialog, qOverload<>(&QDialog::close));

        QMetaObject::connectSlotsByName(loginDialog);
    } // setupUi

    void retranslateUi(QDialog *loginDialog)
    {
        loginDialog->setWindowTitle(QCoreApplication::translate("loginDialog", "Dialog", nullptr));
        groupBox->setTitle(QCoreApplication::translate("loginDialog", "GroupBox", nullptr));
        username->setPlaceholderText(QCoreApplication::translate("loginDialog", "Username", nullptr));
        password->setPlaceholderText(QCoreApplication::translate("loginDialog", "Password", nullptr));
        loginbutton->setText(QCoreApplication::translate("loginDialog", "Login", nullptr));
        exitbutton->setText(QCoreApplication::translate("loginDialog", "Exit", nullptr));
    } // retranslateUi

};

namespace Ui {
    class loginDialog: public Ui_loginDialog {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_LOGINDIALOG_H
