#pragma once
#include <string>

std::string hash_password(const std::string& password);
